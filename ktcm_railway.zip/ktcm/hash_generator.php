<?php
// ============================================
// HASH GENERATOR — Run ONCE then DELETE!
// Visit: https://yourdomain.com/ktcm/hash_generator.php
// ============================================
require_once 'config.php';
echo "<html><head><style>body{font-family:Arial,sans-serif;padding:30px;background:#070f4a;color:white}
h2{color:#f472b6}p.ok{color:#6ee7b7}p.err{color:#fca5a5}p.warn{color:#f0b429}
</style></head><body>";
echo "<h2>KTCM E-Vote — PIN Hash Generator</h2>";
echo "<p>Hashing all plain-text PINs and passwords...</p>";

// Hash student PINs
$students = $conn->query("SELECT id, pin FROM students");
$count = 0;
while ($s = $students->fetch_assoc()) {
    if (strlen($s['pin']) < 20) { // Not yet hashed
        $hashed = password_hash($s['pin'], PASSWORD_DEFAULT);
        $conn->query("UPDATE students SET pin='$hashed' WHERE id={$s['id']}");
        $count++;
    }
}
echo "<p class='ok'>✅ Hashed $count student PINs successfully.</p>";

// Hash admin passwords
$admins = $conn->query("SELECT id, password FROM admins");
$acount = 0;
while ($a = $admins->fetch_assoc()) {
    if (strlen($a['password']) < 20) {
        $hashed = password_hash($a['password'], PASSWORD_DEFAULT);
        $conn->query("UPDATE admins SET password='$hashed' WHERE id={$a['id']}");
        $acount++;
    }
}
echo "<p class='ok'>✅ Hashed $acount admin password(s).</p>";
echo "<p class='warn'>⚠️ <strong>IMPORTANT: Delete this file (hash_generator.php) from your server NOW!</strong></p>";
echo "<p><a href='index.html' style='color:#f472b6'>→ Go to Voting Portal</a> &nbsp; 
     <a href='admin.html' style='color:#f472b6'>→ Go to Admin Panel</a></p>";
echo "</body></html>";
?>