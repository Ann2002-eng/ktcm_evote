<?php
// ============================================
// CONFIG.PHP — Hardened for Production
// Kiharu Technical College Murang'a
// ============================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'eschool_voting');

// ---- SECURE SESSION SETTINGS ----
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_samesite', 'Strict');
ini_set('session.gc_maxlifetime', 1800); // 30 min timeout

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ---- SECURITY HEADERS ----
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');

// ---- DATABASE CONNECTION ----
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    http_response_code(500);
    die(json_encode(['error' => 'Database connection failed.']));
}
$conn->set_charset('utf8mb4');

// ---- PREPARED STATEMENT HELPER ----
function dbQuery($conn, $sql, $types = '', $params = []) {
    $stmt = $conn->prepare($sql);
    if (!$stmt) return false;
    if ($types && $params) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    return $stmt;
}

// ---- SANITIZE INPUT ----
function sanitize($conn, $value) {
    return $conn->real_escape_string(trim(strip_tags($value)));
}

// ---- JSON RESPONSE ----
function jsonResponse($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

// ---- GENERATE RECEIPT CODE ----
function generateReceipt() {
    return 'VR-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
}

// ---- RATE LIMIT CHECK ----
// Max 10 login attempts per IP per 15 minutes
function checkRateLimit($conn, $ip) {
    $ip = $conn->real_escape_string($ip);
    $window = date('Y-m-d H:i:s', strtotime('-15 minutes'));
    $result = $conn->query("SELECT COUNT(*) as cnt FROM login_attempts WHERE ip_address='$ip' AND attempted_at > '$window'");
    $row = $result->fetch_assoc();
    if ($row['cnt'] >= 10) {
        return false; // Rate limited
    }
    return true;
}

// ---- LOG LOGIN ATTEMPT ----
function logAttempt($conn, $ip, $student_id = null) {
    $ip = $conn->real_escape_string($ip);
    $sid = $student_id ? "'".($conn->real_escape_string($student_id))."'" : 'NULL';
    $conn->query("INSERT INTO login_attempts (ip_address, student_id) VALUES ('$ip', $sid)");
    // Clean old attempts (keep DB small)
    $conn->query("DELETE FROM login_attempts WHERE attempted_at < DATE_SUB(NOW(), INTERVAL 1 HOUR)");
}

// ---- LOG AUDIT ----
function logAudit($conn, $action, $desc, $by = 'System') {
    $action = $conn->real_escape_string($action);
    $desc   = $conn->real_escape_string($desc);
    $by     = $conn->real_escape_string($by);
    $ip     = $conn->real_escape_string($_SERVER['REMOTE_ADDR'] ?? '');
    $conn->query("INSERT INTO audit_log (action, description, performed_by, ip_address) VALUES ('$action','$desc','$by','$ip')");
}

// ---- CSRF TOKEN ----
function getCsrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCsrf($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}
?>
