-- ============================================
-- E-SCHOOL VOTING SYSTEM DATABASE (FIXED)
-- Kiharu Technical College - KNEC Practical
-- ============================================

CREATE DATABASE IF NOT EXISTS eschool_voting;
USE eschool_voting;

-- Drop existing tables if any
DROP TABLE IF EXISTS votes;
DROP TABLE IF EXISTS candidates;
DROP TABLE IF EXISTS positions;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS election_settings;
DROP TABLE IF EXISTS admins;

-- STUDENTS TABLE
CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20) UNIQUE NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    class VARCHAR(20) NOT NULL,
    pin VARCHAR(255) NOT NULL,
    has_voted TINYINT(1) DEFAULT 0,
    device_fingerprint VARCHAR(255) DEFAULT NULL,
    voted_at DATETIME DEFAULT NULL,
    receipt_code VARCHAR(20) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- POSITIONS TABLE
CREATE TABLE positions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    display_order INT DEFAULT 0
);

-- CANDIDATES TABLE
CREATE TABLE candidates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    position_id INT NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    class VARCHAR(20) NOT NULL,
    manifesto TEXT,
    photo VARCHAR(255) DEFAULT 'default.png',
    vote_count INT DEFAULT 0,
    FOREIGN KEY (position_id) REFERENCES positions(id) ON DELETE CASCADE
);

-- VOTES TABLE
CREATE TABLE votes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    receipt_code VARCHAR(20) NOT NULL,
    position_id INT NOT NULL,
    candidate_id INT NOT NULL,
    voted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (position_id) REFERENCES positions(id),
    FOREIGN KEY (candidate_id) REFERENCES candidates(id)
);

-- ELECTION SETTINGS TABLE
CREATE TABLE election_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    election_name VARCHAR(200) NOT NULL,
    school_name VARCHAR(200) NOT NULL,
    start_time DATETIME NOT NULL,
    end_time DATETIME NOT NULL,
    status ENUM('pending','active','closed') DEFAULT 'pending',
    winner_announced TINYINT(1) DEFAULT 0
);

-- ADMIN TABLE
CREATE TABLE admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL
);

-- ============================================
-- SAMPLE DATA
-- ============================================

-- Admin (password: admin123)
INSERT INTO admins (username, password, full_name) VALUES
('admin', '$2y$10$8K1p/a0dR1xqM4uJFbGJZOBcJxJkL9e8YQKjF4N2mHsWvXpL6Gy0i', 'System Administrator');

-- Election Settings (7 days from now)
INSERT INTO election_settings (election_name, school_name, start_time, end_time, status) VALUES
('2026 Student Leadership Elections', 'Kiharu Technical College', NOW(), DATE_ADD(NOW(), INTERVAL 7 DAY), 'active');

-- Positions
INSERT INTO positions (title, description, display_order) VALUES
('School President', 'Overall student body leader', 1),
('Vice President', 'Assistant to the school president', 2),
('Secretary General', 'Handles communication and records', 3),
('Treasurer', 'Manages student council finances', 4);

-- Candidates
INSERT INTO candidates (position_id, full_name, class, manifesto) VALUES
(1, 'Alice Wanjiku', 'ICT Diploma 2', 'I will improve school Wi-Fi, introduce student mentorship programs, and ensure every student voice is heard. Together we rise!'),
(1, 'Brian Kamau', 'Business Diploma 3', 'My agenda: Better canteen food, more study spaces, and transparent student council operations. Vote for real change!'),
(1, 'Carol Muthoni', 'Engineering Diploma 2', 'Stronger industry attachments, improved labs, and a student welfare fund. I bring leadership with experience!'),
(2, 'Daniel Otieno', 'ICT Diploma 3', 'Supporting the president with innovation and discipline. I will bridge the gap between students and management.'),
(2, 'Faith Njeri', 'Nursing Diploma 2', 'I believe in unity and service. My focus is on mental health awareness and student counseling support.'),
(3, 'George Mwangi', 'Business Diploma 2', 'Transparent communication, proper meeting minutes, and an active student notice board. Accountability starts here!'),
(3, 'Hannah Achieng', 'ICT Diploma 1', 'Digital-first secretary. I will create an online student portal and keep everyone informed in real time.'),
(4, 'Isaac Njoroge', 'Accounting Diploma 3', 'Certified financial management skills. I will account for every shilling and publish monthly council reports.'),
(4, 'Jane Wambui', 'Business Diploma 1', 'Financial discipline and student empowerment. My goal: a fully-funded student welfare kitty by June.');

-- Students with PIN = 1234 (stored as plain MD5 for simplicity, we'll update api.php to match)
-- PIN 1234 => we store it as plain text and update the login check
INSERT INTO students (student_id, full_name, class, pin) VALUES
('KTCM/001/2026', 'John Maina', 'ICT Diploma 2', '1234'),
('KTCM/002/2026', 'Mary Wangui', 'Business Diploma 3', '1234'),
('KTCM/003/2026', 'Peter Kariuki', 'Engineering Diploma 2', '1234'),
('KTCM/004/2026', 'Susan Nyambura', 'Nursing Diploma 2', '1234'),
('KTCM/005/2026', 'James Ochieng', 'ICT Diploma 1', '1234');
