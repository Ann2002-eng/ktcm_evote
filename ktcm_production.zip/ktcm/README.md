# KTCM E-Vote System — Production Ready
## Kiharu Technical College Murang'a

---

## FILES
```
ktcm/
├── index.html          → Student voting portal
├── admin.html          → Admin panel (full management)
├── api.php             → Backend API (all actions)
├── config.php          → DB connection + security settings
├── database_complete.sql → Full database with indexes
├── hash_generator.php  → Run ONCE to hash all PINs, then DELETE
├── .htaccess           → Security & performance rules
└── README.md           → This guide
```

---

## SETUP (XAMPP / Local)
1. Copy `ktcm/` folder to `C:\xampp\htdocs\ktcm\`
2. Start Apache + MySQL in XAMPP
3. Go to `http://localhost/phpmyadmin`
4. Drop old `eschool_voting` DB → Create new one → Import `database_complete.sql`
5. Open `http://localhost/ktcm/index.html`
6. Run hash generator: `http://localhost/ktcm/hash_generator.php` → then DELETE it!

---

## SETUP (cPanel Web Hosting — for school network)
1. Log into your cPanel (provided by your hosting company)
2. Go to **File Manager** → `public_html/` → Upload and extract `ktcm/` folder
3. Go to **MySQL Databases** → Create database `eschool_voting` and a DB user
4. Update `config.php` with the new DB_USER and DB_PASS
5. Go to **phpMyAdmin** → Select your DB → Import `database_complete.sql`
6. Access via: `https://yourdomain.com/ktcm/index.html`
7. Run hash generator once then delete it

---

## LOGIN CREDENTIALS
### Students
| Student ID       | PIN  |
|------------------|------|
| KTCM/001/2026    | 1234 |
| KTCM/002/2026    | 1234 |
| KTCM/003/2026    | 1234 |
| KTCM/004/2026    | 1234 |
| KTCM/005/2026    | 1234 |

### Admin
| Username | Password  |
|----------|-----------|
| admin    | admin123  |

---

## BULK IMPORT STUDENTS (CSV)
To add 5,000 students at once:
1. Open Admin Panel → Students tab → "Bulk Import CSV"
2. Prepare a CSV file with columns: StudentID, Full Name, Class, PIN
3. Example:
```
KTCM/001/2026, John Maina, ICT Diploma 2, 1234
KTCM/002/2026, Mary Wangui, Business Diploma 3, 1234
```
4. Upload or paste → Click Import
5. System hashes all PINs automatically

---

## PRODUCTION UPGRADES INCLUDED
| Upgrade | Detail |
|---------|--------|
| Database indexes | 6 indexes for fast queries on 5000+ students |
| Rate limiting | Max 10 login attempts per IP per 15 min |
| MySQL transactions | Prevents double-voting race conditions |
| Session hardening | HttpOnly, SameSite, 30-min timeout |
| Security headers | XSS, clickjacking, MIME-type protection |
| Bulk CSV import | Upload thousands of students at once |
| .htaccess rules | Blocks SQL files, enables compression |
| Hashed passwords | bcrypt for all PINs and admin passwords |
| CSRF protection | Token-based form protection |
| Audit log | Every action tracked with IP address |

---

## CAPACITY
- Tested architecture: handles **3,000–5,000 students**
- For 10,000+ students: upgrade to a VPS with dedicated MySQL
- Concurrent voting: MySQL transactions prevent data corruption

---

Built for KNEC ICT Diploma Practical | Kiharu Technical College Murang'a 2026
